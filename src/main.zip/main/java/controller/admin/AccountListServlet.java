package controller.admin;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

/**
 * AccountListServlet
 *
 * Servlet này hiển thị danh sách tài khoản người dùng cho quản trị viên.
 * Hỗ trợ tìm kiếm theo từ khóa (username, họ tên, email, số điện thoại).
 */
@WebServlet(name = "AccountListServlet", urlPatterns = {"/admin/account/list"})
public class AccountListServlet extends HttpServlet {

    /**
     * Xử lý cả GET và POST: hiển thị danh sách hoặc tìm kiếm tài khoản.
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Lấy từ khóa tìm kiếm từ request
        String keyword = request.getParameter("keyword");

        AccountDAO dao = new AccountDAO();
        List<AccountDTO> accounts;

        if (keyword != null && !keyword.trim().isEmpty()) {
            // Tìm kiếm theo keyword (username, họ tên, email, số điện thoại)
            accounts = dao.searchAccounts(keyword.trim());
            request.setAttribute("keyword", keyword.trim()); // giữ lại giá trị tìm kiếm cho UI
        } else {
            // Nếu không có từ khóa thì hiển thị toàn bộ tài khoản
            accounts = dao.getAllAccounts();
        }

        // Truyền danh sách tài khoản về view
        request.setAttribute("accounts", accounts);
        request.getRequestDispatcher("/WEB-INF/view/admin/account/list.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Admin - Quản lý danh sách tài khoản người dùng với tìm kiếm.";
    }
}
