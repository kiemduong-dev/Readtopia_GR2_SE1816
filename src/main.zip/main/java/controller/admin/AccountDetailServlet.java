package controller.admin;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/**
 * AccountDetailServlet
 * 
 * Hiển thị chi tiết thông tin tài khoản cho Admin.
 * Chỉ hỗ trợ phương thức GET.
 */
@WebServlet(name = "AccountDetailServlet", urlPatterns = {"/admin/account/detail"})
public class AccountDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");

        if (username == null || username.trim().isEmpty()) {
            response.sendRedirect("list");
            return;
        }

        AccountDAO dao = new AccountDAO();
        AccountDTO account = dao.getAccountByUsername(username.trim());

        if (account == null) {
            // Có thể custom lỗi: hiển thị trang báo lỗi
            response.sendRedirect("list");
            return;
        }

        request.setAttribute("account", account);
        request.getRequestDispatcher("/WEB-INF/view/admin/account/detail.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("list"); // Không hỗ trợ POST
    }

    @Override
    public String getServletInfo() {
        return "Displays detailed information of an account for admin view.";
    }
}
