package controller.admin;

import dao.AccountDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/**
 * AccountDeleteServlet
 *
 * Xử lý yêu cầu xóa tài khoản người dùng theo username từ Admin Dashboard.
 */
@WebServlet(name = "AccountDeleteServlet", urlPatterns = {"/admin/account/delete"})
public class AccountDeleteServlet extends HttpServlet {

    /**
     * Cho phép xử lý bằng cả GET và POST để linh hoạt.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processDelete(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processDelete(request, response);
    }

    /**
     * Thực hiện logic xóa tài khoản theo username.
     */
    private void processDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String username = request.getParameter("username");
        HttpSession session = request.getSession();

        if (username != null && !username.trim().isEmpty()) {
            AccountDAO dao = new AccountDAO();
            boolean deleted = dao.deleteAccount(username.trim());

            if (deleted) {
                session.setAttribute("message", "✅ Account \"" + username + "\" deleted successfully.");
            } else {
                session.setAttribute("message", "❌ Failed to delete account \"" + username + "\".");
            }
        } else {
            session.setAttribute("message", "⚠️ Invalid username. Deletion aborted.");
        }

        response.sendRedirect(request.getContextPath() + "/admin/account/list");
    }

    @Override
    public String getServletInfo() {
        return "Handles deletion of user accounts by admin.";
    }
}
