package controller.admin;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Date;

/**
 * Servlet that handles the functionality for an admin to add a new account.
 * Supports both GET (display form) and POST (handle submission).
 */
@WebServlet(name = "AccountAddServlet", urlPatterns = {"/admin/account/add"})
public class AccountAddServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 👉 Hiển thị form thêm tài khoản
        request.getRequestDispatcher("/WEB-INF/view/admin/account/add.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            // ✅ Lấy dữ liệu từ form
            String username = request.getParameter("username").trim();
            String firstName = request.getParameter("firstName").trim();
            String lastName = request.getParameter("lastName").trim();
            String email = request.getParameter("email").trim();
            String phone = request.getParameter("phone").trim();
            String address = request.getParameter("address").trim();
            String dobRaw = request.getParameter("dob");
            int role = Integer.parseInt(request.getParameter("role"));
            int sex = Integer.parseInt(request.getParameter("sex"));

            Date dob = (dobRaw != null && !dobRaw.isEmpty()) ? Date.valueOf(dobRaw) : null;

            // ✅ Mật khẩu mặc định (sẽ được hash trong DAO)
            String rawPassword = "123456";

            // ✅ Tạo đối tượng AccountDTO (với raw password)
            AccountDTO acc = new AccountDTO(username, rawPassword, firstName, lastName, dob, email, phone,
                    role, address, sex, 1, null); // accStatus = 1 (active)

            // ✅ Gọi DAO để thêm tài khoản
            AccountDAO dao = new AccountDAO();
            boolean added = dao.addAccount(acc);

            if (added) {
                // ✅ Thành công → chuyển về danh sách
                response.sendRedirect("list");
            } else {
                // ❌ Không thành công → giữ lại dữ liệu nhập & báo lỗi
                request.setAttribute("error", "❌ Failed to add account. Username or email may already exist.");
                request.setAttribute("account", acc);
                request.getRequestDispatcher("/WEB-INF/view/admin/account/add.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "❌ Invalid input. Please check the form.");
            request.getRequestDispatcher("/WEB-INF/view/admin/account/add.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Admin adds a new user account.";
    }
}
