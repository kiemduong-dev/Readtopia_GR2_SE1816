package controller;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        // Nếu là GET → hiển thị form đăng nhập
        if ("GET".equalsIgnoreCase(request.getMethod())) {
            request.getRequestDispatcher("/WEB-INF/view/account/login.jsp").forward(request, response);
            return;
        }

        // Lấy thông tin người dùng nhập
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Sử dụng DAO login() để kiểm tra tài khoản
        AccountDAO dao = new AccountDAO();
        AccountDTO account = dao.login(username, password); // ✅ đã kiểm tra hash bên trong

        if (account != null) {
            // ✅ Đăng nhập thành công → lưu vào session
            HttpSession session = request.getSession();
            session.setAttribute("account", account);

            // Điều hướng theo vai trò
            int role = account.getRole();
            switch (role) {
                case 0: // Admin
                case 2: // Seller Staff
                case 3: // Warehouse Staff
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                    break;
                default: // Customer
                    response.sendRedirect(request.getContextPath() + "/home");
                    break;
            }
        } else {
            // ❌ Sai tài khoản hoặc mật khẩu
            request.setAttribute("error", "❌ Invalid username or password.");
            request.getRequestDispatcher("/WEB-INF/view/account/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Handles login logic and redirects users based on roles.";
    }
}
