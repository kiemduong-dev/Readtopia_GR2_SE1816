package controller;

import dao.AccountDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet(name = "VerifyOTPResetServlet", urlPatterns = {"/verify-otp-reset"})
public class VerifyOTPResetServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false); // Không tạo mới nếu chưa có

        // ❌ Kiểm tra session hợp lệ
        if (session == null
                || session.getAttribute("otp") == null
                || session.getAttribute("resetUser") == null
                || !"reset".equals(session.getAttribute("otpPurpose"))) {

            System.out.println("⚠️ Invalid session. Redirecting to forgot-password.");
            response.sendRedirect(request.getContextPath() + "/forgot-password");
            return;
        }

        String enteredOtp = request.getParameter("otp");
        String sessionOtp = (String) session.getAttribute("otp");
        String username = (String) session.getAttribute("resetUser");

        // ✅ So sánh OTP người dùng nhập với OTP trong session
        if (enteredOtp == null || !enteredOtp.equals(sessionOtp)) {
            request.setAttribute("error", "❌ Invalid OTP. Please try again.");
            request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-reset.jsp").forward(request, response);
            return;
        }

        // ✅ Kiểm tra OTP chính xác bằng DB (AccountDAO) để đảm bảo bảo mật 2 lớp
        AccountDAO dao = new AccountDAO();
        if (!dao.verifyOTP(username, enteredOtp)) {
            request.setAttribute("error", "❌ OTP mismatch or expired. Please request again.");
            request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-reset.jsp").forward(request, response);
            return;
        }

        // ✅ OTP hợp lệ → đánh dấu đã xác thực để cho phép reset password
        session.setAttribute("verifiedReset", true);

        // ✅ Tiến đến form đặt lại mật khẩu
        request.getRequestDispatcher("/WEB-INF/view/account/resetPassword.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 🚫 Không cho phép truy cập trực tiếp GET
        response.sendRedirect(request.getContextPath() + "/forgot-password");
    }
}
