package controller;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet(name = "VerifyOTPRegisterServlet", urlPatterns = {"/verify-otp-register"})
public class VerifyOTPRegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false); // ❗Không tạo mới

        // ❌ Session không hợp lệ
        if (session == null ||
            session.getAttribute("otp") == null ||
            session.getAttribute("pendingAccount") == null ||
            !"register".equals(session.getAttribute("otpPurpose"))) {

            request.setAttribute("error", "⚠️ Session expired or invalid. Please register again.");
            request.getRequestDispatcher("/WEB-INF/view/account/register.jsp").forward(request, response);
            return;
        }

        String enteredOtp = request.getParameter("otp");
        String sessionOtp = (String) session.getAttribute("otp");

        // ❌ OTP không đúng
        if (enteredOtp == null || !enteredOtp.equals(sessionOtp)) {
            request.setAttribute("error", "❌ Invalid OTP. Please check and try again.");
            request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-register.jsp").forward(request, response);
            return;
        }

        try {
            // ✅ OTP hợp lệ → tạo tài khoản
            AccountDTO account = (AccountDTO) session.getAttribute("pendingAccount");
            AccountDAO dao = new AccountDAO();

            boolean success = dao.addAccount(account);

            if (success) {
                // 🧹 Xoá session tạm
                session.removeAttribute("otp");
                session.removeAttribute("otpPurpose");
                session.removeAttribute("pendingAccount");

                // ✅ Thành công
                request.setAttribute("success", "🎉 Account created successfully. You can now log in.");
                request.getRequestDispatcher("/WEB-INF/view/account/login.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "❌ Failed to save account. Please try again.");
                request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-register.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "❌ Server error: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-register.jsp").forward(request, response);
        }
    }
}
