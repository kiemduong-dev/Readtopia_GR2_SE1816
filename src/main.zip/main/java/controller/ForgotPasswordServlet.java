package controller;

import dao.AccountDAO;
import dto.AccountDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import util.MailUtil;

import java.io.IOException;
import java.util.Random;

@WebServlet(name = "ForgotPasswordServlet", urlPatterns = {"/forgot-password"})
public class ForgotPasswordServlet extends HttpServlet {

    private String generateOTP() {
        Random rand = new Random();
        int otp = 100000 + rand.nextInt(900000);
        return String.valueOf(otp);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/view/account/forgotPassword.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String email = request.getParameter("email");
        HttpSession session = request.getSession();
        AccountDAO dao = new AccountDAO();

        try {
            // Tìm account theo email
            AccountDTO account = dao.findByEmail(email);
            if (account == null) {
                request.setAttribute("error", "❌ Email not found.");
                request.getRequestDispatcher("/WEB-INF/view/account/forgotPassword.jsp").forward(request, response);
                return;
            }

            // Sinh OTP và lưu
            String otp = generateOTP();
            String username = account.getUsername();

            // Gửi OTP
            MailUtil.sendOTP(email, otp);

            // Lưu vào DB và session
            dao.saveOTPForReset(username, otp);
            session.setAttribute("otp", otp);
            session.setAttribute("resetUser", username);
            session.setAttribute("resetEmail", email);
            session.setAttribute("otpPurpose", "reset");

            // Chuyển trang nhập OTP
            request.getRequestDispatcher("/WEB-INF/view/account/verify-otp-reset.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "❌ Failed to send OTP: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/view/account/forgotPassword.jsp").forward(request, response);
        }
    }
}
